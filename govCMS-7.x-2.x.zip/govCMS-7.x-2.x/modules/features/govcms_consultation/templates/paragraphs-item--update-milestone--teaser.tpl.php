<?php
/**
 * @file
 * Channels theme implementation for a container.
 */
?>
<div class="consultation__update--extra">
  <div class="consultation__update--extra__icon"><?php print render($content['field_update_type_term']); ?></div>
  <div class="consultation__update--extra__title"><?php print render($content['field_pbundle_destination']); ?></div>
  <div class="consultation__update--extra__date"><?php print render($content['field_update_date']); ?></div>
</div>
