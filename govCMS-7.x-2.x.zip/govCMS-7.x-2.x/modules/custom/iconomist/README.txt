Iconomist
=========

Iconomist is module that allows you to add icons to your drupal site, for
example adding Apple touch icons for iPhone, iPad etc. Each device supports a
different size icon so the module allows you to upload multiple icons and set
the dimension for that icon.

Usage
------------------------------------------------------------------------------

* Goto theme settings (Appearance -> Settings)
* Check 'Iconomist Icons' so the added icons will be added to the theme
* In Iconomist settings add icons
  - Icon relationship specifies the type of icon (includes support for apple
    touch icons)
  - Different devices support different icon dimensions. Use width/height fields
    for each icon size you add
