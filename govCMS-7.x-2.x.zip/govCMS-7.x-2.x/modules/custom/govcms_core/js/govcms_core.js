/**
 * Remove the set timezone behaviour.
 */
Drupal.behaviors.setTimezone = null;
