<?php

/**
 * @file
 * Contains theme-settings form.
 */

/**
 * Implements hook_form_system_theme_settings_alter().
 */
function govcms_zen_form_system_theme_settings_alter(&$form, &$form_state, $form_id = NULL) {
}
